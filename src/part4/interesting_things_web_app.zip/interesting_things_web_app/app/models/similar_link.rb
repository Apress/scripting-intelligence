class SimilarLink < ActiveRecord::Base
end
