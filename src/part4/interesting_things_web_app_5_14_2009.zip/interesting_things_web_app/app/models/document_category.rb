class DocumentCategory < ActiveRecord::Base
end
