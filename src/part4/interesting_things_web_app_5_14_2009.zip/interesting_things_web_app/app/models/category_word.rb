class CategoryWord < ActiveRecord::Base
end
