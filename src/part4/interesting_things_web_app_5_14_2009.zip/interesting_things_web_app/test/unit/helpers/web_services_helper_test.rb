require 'test_helper'

class WebServicesHelperTest < ActionView::TestCase
end
